letra = input("Dígame una letra: ")

if letra.isalpha():
    mayuscula = letra.isupper()

    if mayuscula == True:
        print("La letra es mayúscula")

    if mayuscula == False:
        print("La letra es minúscula")
else:
    print("La letra es mayúscula ¿?")
